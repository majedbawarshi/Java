package a;

public class ab {

	public static void main(String[] args) {
		int x=10;
		int y=0;
		System.out.println(Math.pow(10,2));
	}
	
}
