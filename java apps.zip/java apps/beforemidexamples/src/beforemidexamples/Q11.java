package beforemidexamples;
import java.util.Random; 
import java.util.Scanner;
public class Q11 {

	public static void main(String[] args) {
		 Random rand = new Random(); 
		 Scanner input= new Scanner(System.in);
		 
	}

}
