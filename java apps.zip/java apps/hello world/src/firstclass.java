class firstclass{
	public static void main(String[ ] args) {
	    Scanner myVar = new Scanner(System.in);
	    System.out.println(myVar.nextLine());        
	  }
}