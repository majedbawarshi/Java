import java.util.Scanner;
public class output {
	
	 public static void main(String[] args) {
		 Scanner a = new Scanner(System.in);
		 int x;
	        System.out.println("enter a number"); 
	        x=a.nextLine();
	    }
}
